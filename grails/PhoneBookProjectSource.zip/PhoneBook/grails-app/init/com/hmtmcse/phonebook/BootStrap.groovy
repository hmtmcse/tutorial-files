package com.hmtmcse.phonebook

class BootStrap {


    def init = { servletContext ->

    }

    def destroy = {
    }
}

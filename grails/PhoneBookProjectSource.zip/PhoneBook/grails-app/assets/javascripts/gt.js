/**
 * User: H.M.Touhid Mia
 */

GT = {}
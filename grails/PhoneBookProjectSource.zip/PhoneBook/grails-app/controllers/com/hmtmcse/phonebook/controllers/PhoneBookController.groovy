package com.hmtmcse.phonebook.controllers

class PhoneBookController {

    def index() { }
}

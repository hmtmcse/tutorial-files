package com.hmtmcse.phonebook.controllers

class RegistrationController {

    def index() { }
}

package com.hmtmcse.phonebook.controllers

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class PhoneBookControllerSpec extends Specification implements ControllerUnitTest<PhoneBookController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}

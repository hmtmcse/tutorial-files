package com.hmtmcse.phonebook

import grails.testing.web.taglib.TagLibUnitTest
import spock.lang.Specification

class UIHelperTagLibSpec extends Specification implements TagLibUnitTest<UIHelperTagLib> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}

package com.hmtmcse.phonebook

import grails.testing.services.ServiceUnitTest
import spock.lang.Specification

class ContactGroupServiceSpec extends Specification implements ServiceUnitTest<ContactGroupService>{

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}

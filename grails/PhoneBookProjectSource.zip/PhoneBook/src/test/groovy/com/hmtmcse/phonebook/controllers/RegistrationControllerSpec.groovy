package com.hmtmcse.phonebook.controllers

import grails.testing.web.controllers.ControllerUnitTest
import spock.lang.Specification

class RegistrationControllerSpec extends Specification implements ControllerUnitTest<RegistrationController> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}

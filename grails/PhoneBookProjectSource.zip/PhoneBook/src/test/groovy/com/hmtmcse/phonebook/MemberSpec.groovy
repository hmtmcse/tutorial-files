package com.hmtmcse.phonebook

import grails.testing.gorm.DomainUnitTest
import spock.lang.Specification

class MemberSpec extends Specification implements DomainUnitTest<Member> {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
        expect:"fix me"
            true == false
    }
}
